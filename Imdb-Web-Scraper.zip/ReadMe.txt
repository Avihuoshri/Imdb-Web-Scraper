Please enter my github's repository ReadMe in the next link : https://github.com/Avihuoshri/Imdb-Web-Scraper


Notes:
Unfortunately I didnt succeed the fuzzy search part, hoping the rest of my assigment is ok.
thank you for the opportunity.