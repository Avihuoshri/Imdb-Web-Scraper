# 🖥️ Imdb-Web-Scraper 🖥️
web scraping for movies in imdb website

##### Please install the folowing:
##### Download chromdriver from https://chromedriver.storage.googleapis.com/index.html?path=88.0.4324.96/
##### pip install pillow
##### pip install selenium
##### pip install Pillow
##### pip install requests



### How to operate the tool : 
### 🌟First step:
#### Open command line or pycharm and run scraper.py:
  <img src="gif instruction/First step.gif" width="600" height="350" ><br><br>
  
  
  
  
### 🌟Seconed step:
#### Write in the search box the movie that you want to search and click the search button
  <img src="gif instruction/Second step.gif" width="350" height="600" > <br><br>
  
### 🌟Third step: 
#### Google chrom browser will open and thw web scraping process start please wait few minutes until the process finish and operate movies.txt file
  <img src="gif instruction/Third step.gif" width="900" height="500" > <br><br>

